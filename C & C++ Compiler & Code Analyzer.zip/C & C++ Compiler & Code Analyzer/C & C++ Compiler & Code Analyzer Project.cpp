
#include <bits/stdc++.h>
using namespace std;

/* ================= PRINT FUNCTIONS ================= */

void printProjectBanner()
{
    cout << "\n";
    cout << "============================================================\n";
    cout << "|                                                          |\n";
    cout << "|            C & C++ COMPILER & CODE ANALYZER              |\n";
    cout << "|                                                          |\n";
    cout << "|   Lexical  |  Syntax  |  Semantic  |  TAC Generator      |\n";
    cout << "|   Symbol Table  |  Error Detection  |  Auto Correction   |\n";
    cout << "|                                                          |\n";
    cout << "============================================================\n\n";
}
void printSection(const string &title)
{
    cout << "\n";
    cout << "============================================================\n";
    cout << " " << title << "\n";
    cout << "============================================================\n";
}

/* ================= TOKEN STRUCTURE ================= */
struct Token
{
    string type, value;
    int line;
};

/* ================= GLOBAL VARIABLES ================= */
set<string> keywords = {"int","float","if","else","while","return"};
map<string,string> symbolTable; // variable -> type
vector<pair<string,string>> intermediateCode; // variable, expression
vector<string> correctedCode;    // corrected code lines
vector<string> errors;           // errors
vector<string> tacCode;          // three-address code
bool errorFound = false;
int tempVarCounter = 1;

/* ================= HELPER: Temp Variable ================= */
string newTemp()
{
    return "t" + to_string(tempVarCounter++);
}


/* ================= LEXICAL ANALYSIS ================= */
vector<Token> lexer(const string& code)
{
    vector<Token> tokens;
    string temp = "";
    int line = 1;

    for(int i=0; i<code.size(); i++)
    {
        char c = code[i];
        if(c=='\n') line++;

        if(isspace(c))
        {
            if(!temp.empty())
            {
                if(keywords.count(temp))
                    tokens.push_back({"KEYWORD", temp, line});
                else if(isdigit(temp[0]))
                    tokens.push_back({"NUMBER", temp, line});
                else
                    tokens.push_back({"IDENTIFIER", temp, line});
                temp.clear();
            }
        }
        else if(ispunct(c))
        {
            if(!temp.empty())
            {
                if(keywords.count(temp))
                    tokens.push_back({"KEYWORD", temp, line});
                else if(isdigit(temp[0]))
                    tokens.push_back({"NUMBER", temp, line});
                else
                    tokens.push_back({"IDENTIFIER", temp, line});
                temp.clear();
            }
            string s(1,c);
            tokens.push_back({"SYMBOL", s, line});
        }
        else temp += c;
    }
    return tokens;
}

/* ================= PARSER + SEMANTIC ANALYSIS ================= */
void analyze(vector<Token>& tokens)
{
    set<string> processed;

    for(int i=0; i<tokens.size(); i++)
    {
        Token t = tokens[i];

        // Declaration
        if(t.type=="KEYWORD" && (t.value=="int"||t.value=="float"))
        {
            if(i+1>=tokens.size() || tokens[i+1].type!="IDENTIFIER")
            {
                string msg = "Syntax Error line " + to_string(t.line) + ": Invalid declaration";
                if(!processed.count(msg))
                {
                    errors.push_back(msg);
                    processed.insert(msg);
                }
                errorFound=true;
            }
            else
            {
                string var = tokens[i+1].value;
                if(symbolTable.count(var))
                {
                    string msg = "Semantic Error line " + to_string(t.line) + ": Variable " + var + " redeclared";
                    if(!processed.count(msg))
                    {
                        errors.push_back(msg);
                        processed.insert(msg);
                    }
                    errorFound=true;
                }
                else
                {
                    symbolTable[var] = t.value;
                    correctedCode.push_back(t.value + " " + var + ";");
                }
            }
        }

        // Assignment
        if(t.type=="IDENTIFIER" && i+2<tokens.size() && tokens[i+1].value=="=")
        {
            string var = t.value;
            string expr = "";
            int j = i+2;
            while(j<tokens.size() && tokens[j].value!=";")
            {
                expr += tokens[j].value;
                j++;
            }

            // Undeclared variable auto-declare
            if(!symbolTable.count(var))
            {
                string msg = "Semantic Error line " + to_string(t.line) + ": Undeclared variable -> " + var;
                if(!processed.count(msg))
                {
                    errors.push_back(msg);
                    processed.insert(msg);
                }
                errorFound=true;
                symbolTable[var] = "int";
                correctedCode.push_back("int " + var + ";");
            }

            // Division by zero detection
            if(expr.find("/0") != string::npos)
            {
                string msg = "Logical Error line " + to_string(t.line) + ": Division by zero detected";
                if(!processed.count(msg))
                {
                    errors.push_back(msg);
                    processed.insert(msg);
                }
                errorFound=true;
                // Replace /0 with /1
                size_t pos = 0;
                while((pos = expr.find("/0", pos)) != string::npos)
                {
                    expr.replace(pos, 2, "/1");
                    pos += 2;
                }
            }

            // Add corrected assignment
            correctedCode.push_back(var + " = " + expr + ";");
            intermediateCode.push_back({var, expr});

            // Generate simple TAC
            string tmpExpr = expr;
            vector<string> tokensExpr;
            string tempStr = "";
            for(char ch : tmpExpr)
            {
                if(ch=='+'||ch=='-'||ch=='*'||ch=='/')
                {
                    if(!tempStr.empty()) tokensExpr.push_back(tempStr);
                    tokensExpr.push_back(string(1,ch));
                    tempStr="";
                }
                else tempStr += ch;
            }
            if(!tempStr.empty()) tokensExpr.push_back(tempStr);

            stack<string> s;
            for(auto &tok : tokensExpr)
            {
                if(tok=="+"||tok=="-"||tok=="*"||tok=="/")
                {
                    if(s.size()<2) continue;
                    string rhs = s.top();
                    s.pop();
                    string lhs = s.top();
                    s.pop();
                    string tempVar = newTemp();
                    tacCode.push_back(tempVar + " = " + lhs + " " + tok + " " + rhs);
                    s.push(tempVar);
                }
                else s.push(tok);
            }
            if(!s.empty())
            {
                string finalVar = s.top();
                tacCode.push_back(var + " = " + finalVar);
            }
        }

        // Missing semicolon
        if((t.type=="IDENTIFIER" || t.type=="NUMBER") && i+1<tokens.size() && tokens[i+1].value!=";")
        {
            string msg = "Syntax Error line " + to_string(t.line) + ": Missing semicolon";
            if(!processed.count(msg))
            {
                errors.push_back(msg);
                processed.insert(msg);
            }
            errorFound=true;
        }
    }
}

/* ================= PRINT FUNCTIONS ================= */
void printTokens(vector<Token>& tokens)
{
    printSection("LEXICAL ANALYSIS : TOKENS");

    cout<<left<<setw(15)<<"Type"<<setw(15)<<"Value"<<setw(10)<<"Line"<<endl;
    cout<<"------------------------------------------------------------\n";
    for(auto &t:tokens)
        cout<<left<<setw(15)<<t.type<<setw(15)<<t.value<<setw(10)<<t.line<<endl;
}


void printSymbolTable()
{
    printSection("SYMBOL TABLE");

    cout<<left<<setw(20)<<"Variable"<<setw(15)<<"Type"<<endl;
    cout<<"------------------------------------------------------------\n";
    for(auto &x:symbolTable)
        cout<<left<<setw(20)<<x.first<<setw(15)<<x.second<<endl;
}


void printIntermediateCode()
{
    printSection("INTERMEDIATE CODE");

    cout<<left<<setw(5)<<"No."<<setw(20)<<"Variable"<<setw(25)<<"Expression"<<endl;
    cout<<"------------------------------------------------------------\n";

    int idx=1;
    for(auto &x:intermediateCode)
        cout<<left<<setw(5)<<idx++<<setw(20)<<x.first<<setw(25)<<x.second<<endl;
}



void printTAC()
{
    printSection("THREE ADDRESS CODE (TAC)");

    int idx=1;
    for(auto &line:tacCode)
        cout<<setw(3)<<idx++<<". "<<line<<endl;
}


void printErrors()
{
    printSection("ERROR REPORT");

    if(errors.empty())
    {
        cout<<"No errors detected.\n";
        return;
    }

    int idx=1;
    for(auto &e:errors)
        cout<<idx++<<". "<<e<<endl;
}


void printCorrectedCode()
{
    printSection("AUTO-CORRECTED CODE");

    for(auto &line:correctedCode)
        cout<<line<<endl;
}


/* ================= MAIN ================= */
int main()
{

    printProjectBanner();

    cout<<"Enter Mini-C code (end input with # on a new line):\n";

    string code, line;
    while(true)
    {
        getline(cin,line);
        if(line=="#") break;
        code += line + "\n";
    }

    auto tokens = lexer(code);
    printTokens(tokens);
    analyze(tokens);
    printSymbolTable();
    printIntermediateCode();
    printTAC();
    printErrors();
    printCorrectedCode();

    if(!errorFound)
        cout<<"\nCompilation Successful\n";
    else
        cout<<"\nCompilation Finished with Errors\n";

    printSection("THANK YOU.........");

    cout << "Thank you for using the C & C++ Compiler & Code Analyzer\n";
    cout << "Project completed successfully.\n";
    cout << "Project Team Members : Salsabil, Ruhi, Mahi...\n";



    return 0;
}
